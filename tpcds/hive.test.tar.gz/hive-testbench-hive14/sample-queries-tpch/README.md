Sample TPC-H Queries
====================

This directory contains sample TPC-H queries you can run once you have generated your data. Queries are compatible with Apache Hive 13 and up.
