Sample TPC-DS Queries
=====================

This directory contains sample TPC-DS queries you can run once you have generated your data. Queries are compatible with Apache Hive 14 and up.
